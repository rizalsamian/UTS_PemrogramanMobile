package id.belajar.uts_rizal

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity

class ActivityBiodataMahasiswa : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.biodata_mahasiswa)
    }

    fun menuUtama(view: View){
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }
}