package id.belajar.uts_rizal

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.detail_mata_kuliah.*

class ActivityDetailMakul : AppCompatActivity() {

    companion object {
        const val EXTRA_DOSEN = "extra_nama_dosen"
        const val EXTRA_MAKUL = "extra_makul"
        const val EXTRA_KODE_MAKUL = "extra_makul_kode_makul"
        const val EXTRA_SKS = "extra_sks"
        const val EXTRA_NILAI = "extra_nilai"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.detail_mata_kuliah)

        showDetailMataKuliah()
    }

    private fun showDetailMataKuliah(){
        tvDetailNamaDosen.setText(intent.getStringExtra(EXTRA_DOSEN))
        tvDetailMataKuliah.setText(intent.getStringExtra(EXTRA_MAKUL))
        tvDetailKodeMataKuliah.setText(intent.getStringExtra(EXTRA_KODE_MAKUL))
        tvDetailSks.setText(intent.getStringExtra(EXTRA_SKS))
        tvDetailNilai.setText(intent.getStringExtra(EXTRA_NILAI))
    }
}