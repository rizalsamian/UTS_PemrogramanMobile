package id.belajar.uts_rizal

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class ActivityListMataKuliah : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.list_mata_kuliah)
    }
}