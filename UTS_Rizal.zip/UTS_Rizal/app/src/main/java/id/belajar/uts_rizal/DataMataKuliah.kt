package id.belajar.uts_rizal

class DataMataKuliah (val kodeMakul: String, val namaMakul: String, val namaDosen: String, val sksMakul: String, val nilaiMakul: String, val image : String)