package id.belajar.uts_rizal

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.list_mata_kuliah.view.*


class ListMakulAdapter (val makulItemList: List<DataMataKuliah>, val clickListener: (DataMataKuliah) -> Unit ) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val view = inflater.inflate(R.layout.list_mata_kuliah, parent, false)
        return ListMakulViewHolder(view)
    }

    override fun getItemCount() = makulItemList.size

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        (holder as ListMakulViewHolder).bind(makulItemList[position], clickListener)
    }

    class ListMakulViewHolder(itemView : View) : RecyclerView.ViewHolder(itemView){
        fun bind(makuls : DataMataKuliah, clickListener: (DataMataKuliah) -> Unit) {
            itemView.tvMataKuliah.text = makuls.namaMakul
            itemView.tvNamaDosen.text = makuls.namaDosen
            itemView.setOnClickListener{clickListener(makuls)}
        }
    }

}
