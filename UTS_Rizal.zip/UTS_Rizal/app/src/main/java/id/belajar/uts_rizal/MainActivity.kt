package id.belajar.uts_rizal

import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val testData = createDataMataKuliah()
        rvMataKuliah.layoutManager = LinearLayoutManager(this)
        rvMataKuliah.setHasFixedSize(true)
        rvMataKuliah.adapter = ListMakulAdapter(testData, {makulItem: DataMataKuliah -> makulItemClicked(makulItem)})

        val activities: List<ResolveInfo> = packageManager.queryIntentActivities(
            intent,
            PackageManager.MATCH_DEFAULT_ONLY
        )
        val isIntentSafe: Boolean = activities.isNotEmpty()

    }

    fun menuWebTi(view : View){
        val webIntent: Intent = Uri.parse("https://ti.akakom.ac.id").let { webpage ->
            Intent(Intent.ACTION_VIEW, webpage)
        }
        startActivity(webIntent)
    }

    fun menuMahasiswa(view : View){
        val intent = Intent(this, ActivityBiodataMahasiswa::class.java)
        startActivity(intent)
    }


    private fun makulItemClicked(makulItem: DataMataKuliah){
        val manageDetailIntent = Intent(this@MainActivity, ActivityDetailMakul::class.java).apply {
            putExtra(ActivityDetailMakul.EXTRA_DOSEN, makulItem.namaDosen)
            putExtra(ActivityDetailMakul.EXTRA_MAKUL, makulItem.namaMakul)
            putExtra(ActivityDetailMakul.EXTRA_NILAI, makulItem.nilaiMakul)
            putExtra(ActivityDetailMakul.EXTRA_SKS, makulItem.sksMakul)
            putExtra(ActivityDetailMakul.EXTRA_KODE_MAKUL, makulItem.kodeMakul)
        }

        startActivity(manageDetailIntent)
//        val showDetailActivityIntent =Intent(this, ActivityDetailMakul::class.java)
//        showDetailActivityIntent.putExtra(Intent.EXTRA_TEXT, makulItem.namaDosen)
//        startActivity(showDetailActivityIntent)
    }

    private fun createDataMataKuliah() : List<DataMataKuliah>{
        var partList = ArrayList<DataMataKuliah>()
        partList.add(DataMataKuliah("IF1903T", "Sistem Digital", "Adiyuda Prayitna, S.T., M.T.", "2", "A", "1"))
        partList.add(DataMataKuliah("IF1910T","Analisis Dan Desain Sistem","Deborah Kurniawati, S.Kom., M.Cs.","2","A",""))
        partList.add(DataMataKuliah("IF1910P","Praktikum Analisis dan Desain Sistem","Deborah Kurniawati, S.Kom., M.Cs.","1","A",""))
        partList.add(DataMataKuliah("IK1913P","Praktikum Teknologi Cloud","M. Agung Nugroho, S.Kom., M.Kom.","1","A",""))
        partList.add(DataMataKuliah("IK1913T","Teknologi Cloud","M. Agung Nugroho, S.Kom., M.Kom.","2","A",""))
        partList.add(DataMataKuliah("IK1915T","Teknologi Mobile","Ir. Hardi Tri Nugroho, M.T.","2","A",""))
        partList.add(DataMataKuliah("IK1903T","Pendidikan Kewarganegaraan","Ir. Rizal, M.Cs","2","A",""))
        partList.add(DataMataKuliah("IF1926T","Sistem Pendukung Keputusan","Widyastuti Andriyani, S.Kom., M.Kom.","2","A",""))
        partList.add(DataMataKuliah("IF1922P","Praktikum Pemrograman Berbasis Mobile","Ir. Sudarmanto, M.T.","1","A",""))
        partList.add(DataMataKuliah("IF1922T","Pemrograman Berbasis Mobile","Ir. Sudarmanto, M.T.","3","A",""))
        partList.add(DataMataKuliah("IF1944T","Perancangan Antar Muka","Pius Dian Widi Anggoro, S.Si., M.Cs.","3","A",""))
        partList.add(DataMataKuliah("IF1924T","Data Mining","Ir. Wawan Kurniawan, M.T.","3","A",""))

        return partList
    }


}

